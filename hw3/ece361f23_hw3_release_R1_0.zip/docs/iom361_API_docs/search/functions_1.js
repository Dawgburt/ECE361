var searchData=
[
  ['iom361_5finitialize_0',['iom361_initialize',['../iom361_8c.html#a12599cf51259db2f0111670b285dba8a',1,'iom361_initialize(int num_switches, int num_leds, int *rtn_code):&#160;iom361.c'],['../iom361_8h.html#a12599cf51259db2f0111670b285dba8a',1,'iom361_initialize(int num_switches, int num_leds, int *rtn_code):&#160;iom361.c']]],
  ['iom361_5freadreg_1',['iom361_readReg',['../iom361_8c.html#abcee5694729d1e84ac7adf83f181d02a',1,'iom361_readReg(uint32_t *base, uint32_t offset, int *rtn_code):&#160;iom361.c'],['../iom361_8h.html#abcee5694729d1e84ac7adf83f181d02a',1,'iom361_readReg(uint32_t *base, uint32_t offset, int *rtn_code):&#160;iom361.c']]],
  ['iom361_5fwritereg_2',['iom361_writeReg',['../iom361_8c.html#a92e056048f9db44736e65b7d769855a7',1,'iom361_writeReg(uint32_t *base, int offset, uint32_t value, int *rtn_code):&#160;iom361.c'],['../iom361_8h.html#a92e056048f9db44736e65b7d769855a7',1,'iom361_writeReg(uint32_t *base, int offset, uint32_t value, int *rtn_code):&#160;iom361.c']]]
];
