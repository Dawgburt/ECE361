var searchData=
[
  ['_5fiom361_5fsetsensor1_0',['_iom361_setSensor1',['../iom361_8c.html#ac7d1829c330d0cdbcf069f591f68b709',1,'_iom361_setSensor1(float new_temp, float new_humid):&#160;iom361.c'],['../iom361_8h.html#ac7d1829c330d0cdbcf069f591f68b709',1,'_iom361_setSensor1(float new_temp, float new_humid):&#160;iom361.c']]],
  ['_5fiom361_5fsetswitches_1',['_iom361_setSwitches',['../iom361_8c.html#a756d78799ba3cc2e9d02366da71d4a9d',1,'_iom361_setSwitches(uint32_t value):&#160;iom361.c'],['../iom361_8h.html#a756d78799ba3cc2e9d02366da71d4a9d',1,'_iom361_setSwitches(uint32_t value):&#160;iom361.c']]]
];
