var iom361_8c =
[
    [ "_iom361_setSensor1", "iom361_8c.html#ac7d1829c330d0cdbcf069f591f68b709", null ],
    [ "_iom361_setSwitches", "iom361_8c.html#a756d78799ba3cc2e9d02366da71d4a9d", null ],
    [ "iom361_initialize", "iom361_8c.html#a12599cf51259db2f0111670b285dba8a", null ],
    [ "iom361_readReg", "iom361_8c.html#abcee5694729d1e84ac7adf83f181d02a", null ],
    [ "iom361_writeReg", "iom361_8c.html#a92e056048f9db44736e65b7d769855a7", null ]
];