/*****
 * prob3_starter.c - starter code for nursery rhyme counter
 * 
 * @author: <Your Name> (<Your email)
 * @date:   <Creation date>
 * 
 * This program counts things up like in the "one little indian" nursery-rhyme. 
 */
 
// header files go here
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
 
// contants, typedefs, global variables, etc. go here
#define MAXTHINGS  10 
 
char thing[] = "spider";    // the thing we're counting 
 
// function prototypes go here
void displayCountUp(int count, char thing[], int MaxCount);
 
/********** main() **********/
int main() {
	// greet the user and display the working directory for the application
    // this code should be included in all of the applications you submit for ECE 361
    printf("TODO: ADD YOUR GREETING MESSAGE\n");
    errno = 0;
    char *buf = getcwd(NULL, 0);    // allocates a buffer large enough to hold the path
    
    if (buf == NULL) {
        perror("getcwd");
        printf("Could not display the path\n");
    }
    else {
        printf("Current working directory: %s\n", buf);
        free(buf);
    }
    printf("\n");
	
	// count things in increasing order
    for (int i = 1; i <= MAXTHINGS; i++) {
		// TODO: REPLACE THIS CODE WITH YOUR FUNCTION CALL
		if (i == MAXTHINGS)
            printf("%2d little %s bugs\n", i, thing);
        else if (i % 3 == 0)
            printf("%2d little %ss\n", i, thing);
        else
            printf (" %2d little,", i);
	}
	return 0;
}
 
 /***** helper functions *****/
 
/**
 * displayCountUp() - displays the text for the associated count when counting up
 *
 * @param int count - current count
 * @param char[] thing - text of the item being counted
 * @param int MaxCount - maximum items to count
 * @return	*nothing*
 *
 * displays the count in nursery rhyme format, for example:
 *		1 little
 *		2 little
 *		3 little arachnids
 *		4 little
 *		5 little
 *		6 little arachnids
 *		...
 *		10 little arachnid bugs
 *
 */
void displayCountUp(int count, char thing[], int MaxCount) {  
	// TODO: ADD YOUR CODE HERE
}
